import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getMediaUrl, downloadMedia, sendText } from "@/integrations/whatsapp/client";
import { transcribeAudio } from "@/services/audio/transcribe";
import { runBusinessAgent } from "@/services/ai/agent";
import { incrementUsage } from "@/services/billing/checkLimits";
import { logger } from "@/lib/errors/logger";
import * as Sentry from "@sentry/nextjs";

// Verify Webhook
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");

  const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN;

  if (mode && token) {
    if (mode === "subscribe" && token === VERIFY_TOKEN) {
      return new NextResponse(challenge, { status: 200 });
    }
    return new NextResponse("Forbidden", { status: 403 });
  }
  return new NextResponse("Bad Request", { status: 400 });
}

// Handle Incoming Messages
export async function POST(req: Request) {
  try {
    const body = await req.json();

    if (body.object !== "whatsapp_business_account") {
      return new NextResponse("Not Found", { status: 404 });
    }

    // Process all entries
    for (const entry of body.entry) {
      const changes = entry.changes?.[0];
      if (changes?.field !== "messages") continue;

      const value = changes.value;
      const metadata = value.metadata;
      // This is the number receiving the message
      const displayPhoneNumber = metadata.display_phone_number;
      // Or phone_number_id
      const phoneNumberId = metadata.phone_number_id;

      const messages = value.messages;
      if (!messages || messages.length === 0) continue;

      const message = messages[0];
      const from = message.from; // Sender number

      // 1. Identify Tenant by SENDER'S cell phone number (from) instead of global bot number
      const supabase = createAdminClient();
      
      let cleanedFrom = from.replace("+", "").trim();
      let alternativeFrom = cleanedFrom;
      if (cleanedFrom.startsWith("549") && cleanedFrom.length === 13) {
        alternativeFrom = "54" + cleanedFrom.substring(3);
      } else if (cleanedFrom.startsWith("54") && !cleanedFrom.startsWith("549") && cleanedFrom.length === 12) {
        alternativeFrom = "549" + cleanedFrom.substring(2);
      }

      const { data: waAccount } = await supabase
        .from("whatsapp_numbers")
        .select("tenant_id, access_token")
        .or(`phone_number.eq."${cleanedFrom}",phone_number.eq."${alternativeFrom}",phone_number.eq."+${cleanedFrom}",phone_number.eq."+${alternativeFrom}"`)
        .maybeSingle();

      let tenantId = waAccount?.tenant_id;
      // Use the global WHATSAPP_TOKEN as primary, falling back to the tenant's access_token
      let accessToken = process.env.WHATSAPP_TOKEN || process.env.WHATSAPP_ACCESS_TOKEN || waAccount?.access_token;

      // Fallback para pruebas locales (solo en modo desarrollo)
      if (!tenantId && process.env.NODE_ENV !== 'production') {
        logger.info("Using fallback tenant for testing...", "WHATSAPP_WEBHOOK");
        const { data: firstProfile } = await supabase.from("profiles").select("tenant_id").limit(1).single();
        if (firstProfile) {
          tenantId = firstProfile.tenant_id;
          accessToken = process.env.WHATSAPP_ACCESS_TOKEN!;
        }
      }

      if (!tenantId) {
        logger.error(`Unknown sender number: ${from} writing to ${phoneNumberId}`, "WHATSAPP_WEBHOOK");
        continue;
      }

      let textMessage = "";

      // 2. Extract Text or Audio
      if (message.type === "text") {
        textMessage = message.text.body;
      } else if (message.type === "audio") {
        try {
          const mediaId = message.audio.id;
          const mediaUrl = await getMediaUrl(mediaId, accessToken);
          const buffer = await downloadMedia(mediaUrl, accessToken);
          textMessage = await transcribeAudio(buffer, `${mediaId}.ogg`);
        } catch (error) {
          logger.error(error, "WHATSAPP_AUDIO_PROCESS");
          await sendText(from, "Lo siento, no pude procesar tu audio. ¿Podrías escribirlo?", phoneNumberId, accessToken);
          await incrementUsage(tenantId, "whatsapp_messages_used");
          continue;
        }
      } else {
        await sendText(from, "Stockly solo entiende texto y audios por el momento.", phoneNumberId, accessToken);
        await incrementUsage(tenantId, "whatsapp_messages_used");
        continue;
      }

      // 3. Save Inbound Message
      await supabase.from("messages").insert({
        tenant_id: tenantId,
        channel: "whatsapp",
        text: message.type === "audio" ? `🎙️ [Audio transcrito]: ${textMessage}` : textMessage,
        direction: "inbound",
        raw_payload: { from, to: displayPhoneNumber }
      });

      // 4. Run AI Agent
      const aiResult = await runBusinessAgent({
        tenantId, 
        userMessage: textMessage,
        channel: "whatsapp",
        fromPhone: from
      });

      const responseText = typeof aiResult === "string" ? aiResult : aiResult.response;
      const productId = typeof aiResult === "string" ? null : aiResult.product_id;

      // 5. Save Outbound Message
      await supabase.from("messages").insert({
        tenant_id: tenantId,
        channel: "whatsapp",
        text: responseText,
        direction: "outbound",
        product_id: productId,
        raw_payload: { from: displayPhoneNumber, to: from }
      });

      // Fix para Argentina: Si Meta envía '54911...' pero verificó '5411...'
      let sendTo = from;
      if (sendTo.startsWith("549") && sendTo.length === 13) {
        sendTo = "54" + sendTo.substring(3);
      }

      // 6. Send Response
      try {
        await sendText(sendTo, responseText, phoneNumberId, accessToken);
        await incrementUsage(tenantId, "whatsapp_messages_used");
      } catch (error: any) {
        logger.error(`Error sending WA message to ${sendTo}: ${error.message}`, "WHATSAPP_WEBHOOK");
        // Save the error in the database to debug it easily
        await supabase.from("messages").insert({
          tenant_id: tenantId,
          text: `❌ Error enviando mensaje a WhatsApp: ${error.message}`,
          direction: "outbound",
        });
      }
    }

    return new NextResponse("OK", { status: 200 });
  } catch (error: any) {
    Sentry.captureException(error, { extra: { context: "WHATSAPP_WEBHOOK" } });
    logger.error(error, "WHATSAPP_WEBHOOK");
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
