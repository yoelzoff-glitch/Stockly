"use server";

import { createClient } from "@/lib/supabase/server";
import { createCoupon } from "@/services/meli/promotions/createCoupon";
import { revalidatePath } from "next/cache";

export async function createManualCouponAction(formData: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("No autenticado");

  const { data: profile } = await supabase
    .from("profiles")
    .select("tenant_id")
    .eq("id", user.id)
    .single();

  if (!profile?.tenant_id) throw new Error("Usuario sin tenant");

  const discountType = formData.get("discountType") as string;
  const discountValue = Number(formData.get("discountValue"));
  const targetAudience = formData.get("targetAudience") as string;
  const maxUses = formData.get("maxUses") ? Number(formData.get("maxUses")) : undefined;
  const minPurchaseAmount = formData.get("minPurchaseAmount") ? Number(formData.get("minPurchaseAmount")) : undefined;
  const durationDays = formData.get("durationDays") ? Number(formData.get("durationDays")) : 7;

  if (!discountType || !discountValue) {
    throw new Error("El tipo y valor de descuento son obligatorios");
  }

  // Create duration string
  const duration = `${durationDays} days`;

  const payload = {
    discountType,
    discountValue,
    targetAudience: targetAudience === "general" ? undefined : targetAudience,
    maxUses,
    minPurchaseAmount,
    duration
  };

  // 1. Llamar a la API de Mercado Libre
  await createCoupon(profile.tenant_id, payload);

  // 2. Guardar en base de datos local
  const title = `Cupón Manual ${discountType === 'percent' ? discountValue + '%' : '$' + discountValue} OFF`;
  
  const { error: dbError } = await supabase.from("coupons").insert({
    tenant_id: profile.tenant_id,
    coupon_type: 'standard',
    discount_type: discountType,
    discount_value: discountValue,
    target_audience: targetAudience === "general" ? null : targetAudience,
    status: 'active',
    title: title
  });

  if (dbError) {
    throw new Error(`Error guardando el cupón localmente: ${dbError.message}`);
  }

  revalidatePath("/dashboard/promotions");
  return { success: true };
}
