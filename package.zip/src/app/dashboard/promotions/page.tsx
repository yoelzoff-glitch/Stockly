"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { createManualCouponAction } from "./actions";

export default function PromotionsPage() {
  const [activeTab, setActiveTab] = useState("promotions");
  
  // Coupon modal state
  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleCouponSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setIsSubmitting(true);
    const formData = new FormData(e.currentTarget);
    try {
      await createManualCouponAction(formData);
      setIsCouponModalOpen(false);
      alert("Cupón creado exitosamente en Mercado Libre.");
    } catch (err: any) {
      alert(err.message || "Error al crear el cupón");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Promociones y Cupones</h1>
          <p className="text-slate-500 mt-2">Gestiona las ofertas, descuentos y cupones de tu tienda.</p>
        </div>
        <Button onClick={() => alert('Para crear promociones, puedes pedirle a Klyvo en el chat: "Crear una oferta para..."')}>
          Nueva Promoción con IA
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-white border-slate-200">
          <TabsTrigger value="promotions" className="data-[state=active]:bg-indigo-50 data-[state=active]:text-indigo-700">
            Promociones Activas
          </TabsTrigger>
          <TabsTrigger value="coupons" className="data-[state=active]:bg-indigo-50 data-[state=active]:text-indigo-700">
            Cupones
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-indigo-50 data-[state=active]:text-indigo-700">
            Historial
          </TabsTrigger>
        </TabsList>

        <TabsContent value="promotions" className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-slate-900">No hay promociones activas</h3>
            <p className="mt-2 text-slate-500">Usa el chat de Inteligencia Artificial para crear tu primera oferta relámpago o descuento por porcentaje.</p>
          </div>
        </TabsContent>

        <TabsContent value="coupons" className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex justify-end mb-4">
            <Button variant="outline" onClick={() => setIsCouponModalOpen(true)}>
              Crear Cupón Manual
            </Button>
          </div>
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-slate-900">No hay cupones creados</h3>
            <p className="mt-2 text-slate-500">Pídele a Klyvo: "Generame un cupón de $5000 off para nuevos compradores".</p>
          </div>
        </TabsContent>

        <TabsContent value="history" className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-slate-900">Historial vacío</h3>
            <p className="mt-2 text-slate-500">Aquí aparecerán las promociones finalizadas y fallidas.</p>
          </div>
        </TabsContent>
      </Tabs>

      {/* Manual Coupon Dialog */}
      <Dialog open={isCouponModalOpen} onOpenChange={setIsCouponModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Crear Cupón Manual</DialogTitle>
            <DialogDescription>
              Crea un cupón de descuento válido para todos tus productos de Mercado Libre.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCouponSubmit} className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="discountType">Tipo de Descuento</Label>
                <select name="discountType" id="discountType" className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="percent">Porcentaje (%)</option>
                  <option value="amount">Monto Fijo ($)</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="discountValue">Valor</Label>
                <Input name="discountValue" id="discountValue" type="number" required placeholder="Ej: 15" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetAudience">Audiencia Objetivo</Label>
              <select name="targetAudience" id="targetAudience" className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="general">Todo el público (General)</option>
                <option value="new_buyers">Nuevos compradores</option>
                <option value="followers">Seguidores de la tienda</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="minPurchaseAmount">Compra mínima (Opcional)</Label>
                <Input name="minPurchaseAmount" id="minPurchaseAmount" type="number" placeholder="Ej: 10000" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="maxUses">Límite de usos (Opcional)</Label>
                <Input name="maxUses" id="maxUses" type="number" placeholder="Ej: 50" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="durationDays">Duración en días</Label>
              <Input name="durationDays" id="durationDays" type="number" defaultValue={7} required />
            </div>

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => setIsCouponModalOpen(false)} disabled={isSubmitting}>
                Cancelar
              </Button>
              <Button type="submit" disabled={isSubmitting} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                {isSubmitting ? "Creando..." : "Crear Cupón ML"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
