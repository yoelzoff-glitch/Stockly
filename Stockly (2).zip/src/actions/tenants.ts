"use server";

import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function submitOnboardingAction(prevState: any, formData: FormData) {
  const companyName = formData.get("companyName") as string;
  const category = formData.get("category") as string;
  const country = formData.get("country") as string;
  const currency = formData.get("currency") as string;
  const businessSize = formData.get("businessSize") as string;

  if (!companyName || !category || !country || !currency || !businessSize) {
    return { error: "Todos los campos son obligatorios" };
  }

  const supabase = await createClient();
  const supabaseAdmin = createAdminClient();

  const { data: { user }, error: userError } = await supabase.auth.getUser();

  if (userError || !user) {
    return { error: "No estás autenticado" };
  }

  const slug = companyName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)+/g, "");

  const selectedPlan = user.user_metadata?.plan || "starter";
  const paymentStatus = user.user_metadata?.payment_status || "paid";

  if ((selectedPlan === 'pro' || selectedPlan === 'ultra') && paymentStatus !== 'paid') {
    return { error: "Debes completar el pago de tu suscripción antes de configurar tu entorno." };
  }

  // Crear Tenant
  const { data: tenantData, error: tenantError } = await supabaseAdmin
    .from("tenants")
    .insert([
      {
        name: companyName,
        slug: slug,
        plan: selectedPlan, 
        status: "active",
        currency: currency,
        metadata: {
          category,
          country,
          businessSize,
          onboarded: true,
        }
      },
    ])
    .select()
    .single();

  if (tenantError || !tenantData) {
    console.error("Tenant creation error:", tenantError);
    return { error: `Error al configurar el entorno: ${tenantError?.message || "Desconocido"}` };
  }

  // Update or Create Profile
  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("id")
    .eq("id", user.id)
    .single();

  if (profile) {
    // Update existing profile with tenant_id
    await supabaseAdmin
      .from("profiles")
      .update({ tenant_id: tenantData.id })
      .eq("id", user.id);
  } else {
    // Create new profile if it doesn't exist (from signup)
    await supabaseAdmin
      .from("profiles")
      .insert([
        {
          id: user.id,
          tenant_id: tenantData.id,
          email: user.email,
          role: "owner",
        },
      ]);
  }

  // Calculate expiration date
  let expiresAt = null;
  if (selectedPlan === "starter") {
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + 7);
    expiresAt = expirationDate.toISOString();
  }

  // Create subscription record
  await supabaseAdmin.from("subscriptions").insert({
    tenant_id: tenantData.id,
    plan: selectedPlan,
    status: "active",
    mercadopago_subscription_id: user.user_metadata?.mp_sub_id || null,
    expires_at: expiresAt,
  });

  revalidatePath("/", "layout");
  redirect("/dashboard");
}
